package org.hogwarts;

public class Main {
    public static void main(String[] args) {
        System.out.println("Oh, you’re a magician, friend! Welcome to Hogwarts!");
    }
}