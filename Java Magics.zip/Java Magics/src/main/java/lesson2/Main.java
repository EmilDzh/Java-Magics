package lesson2;

public class Main {
    public static void main(String[] args) {

        String charm = "Wingardium Leviosa";

        // new - это оператор создания разных объектов
        String tergeo = new String("Tergeo");

        String wingardium = "Wingardium ";
        String leviosa = "Leviosa";

        // Будет равно "Wingardium Leviosa"
        String combination = wingardium + leviosa;

        // \n - перенос строки
        String equations = "2 + 2 = 4\n3 + 3 = 9\n";

        // \t - табуляция
        String tabs = "Заголовок!" +
                "\n\tАбзац 1" +
                "\n\tАбзац 2";

        System.out.println(equations + tabs);

        String lines = """
                Protego Maxima!
                Repello Inimicum!
                Fianto Duri!
                                   """;

        String s1 = "Wingardium Leviosa";
        String s2 = "Wingardium" + " " + "Leviosa";
        String s3 = "Wingardium Leviosa Wingardium Leviosa";

        // Получим true
        System.out.println(s1.equals(s2));
        // Получим false
        System.out.println(s1.equals(s3));

        String c1 = "REDUCIO";
        String c2 = "inflatus";

        // Получится "reducio"
        System.out.println(c1.toLowerCase());
        // Получится "INFLATUS";
        System.out.println(c2.toUpperCase());

        /*
         String charm = "CHARM";

         // Получим 'C'
        System.out.println(charm.charAt(0));

          // Получим 'M'
        System.out.println(charm.charAt(4));

        // Получим ошибку, так как в строке нет символа под номером 8
        System.out.println(charm.charAt(8));
        // Получим ошибку, так как не поддерживаются отрицательные индексы
         System.out.println(charm.charAt(-1));

         */

        String str = "Bombarda Maxima!";
        // Получим 16. Пробелы и символы - считаются!
        System.out.println(str.length());

        // Получим true
        boolean charmStart1 = charm.startsWith("Bom");
        // Получим false
        boolean charmStart2 = charm.startsWith("ard");

        // Получим true
        boolean charmEnd1 = charm.endsWith("xima!");
        // Получим false
        boolean charmEnd2 = charm.endsWith("Max");

        // Получим 9, начиная с 9-го символа в строке содержится "Maxima"
        System.out.println(charm.indexOf("Maxima"));
        // Получим -1, потому что такой подстроки нет
        System.out.println(charm.indexOf("schooooooool"));
        // contains вернёт true, если подстрока содержится в строке
        System.out.println(charm.contains("Bom"));
        // contains вернёт false, если подстрока НЕ содержится в строке
        System.out.println(charm.contains("Bum"));

        String result1 = charm.replace("Bombarda", "Wow!"); // заменяет "Bombarda" на "Wow!"
        System.out.println(result1); // получим "Wow! Maxima!"

        String result2 = charm.replaceAll("a", "0"); // заменяет все a в строке charm на 0
        System.out.println(result2); // получим "Bomb0rd0 M0xim0!

        String trim = "\n   \t Accio  \t \n    ";
        String result = trim.trim();
        // получим просто "Accio" - все отступы пропадут, а длина строки изменится
        System.out.println(result);

        /*
        String s1 = " _ ";
        String s2 = "\t      \n";
        String s3 = "";

        // Получим false и false
        System.out.println(s1.isBlank());
        System.out.println(s1.isEmpty());

        // Получим true и false
        System.out.println(s2.isBlank());
        System.out.println(s2.isEmpty());

        // Получим true и true
        System.out.println(s3.isBlank());
        System.out.println(s3.isEmpty());

        String str = "123456";

      // Левая граница включительно, правая не включительно
      String result1 = str.substring(1, 5);
      // Получим строку "2345"
      System.out.println(result1);

      // Начиная со второго индекса
      String result2 = str.substring(2);
      // Получим строку "3456"
      System.out.println(result2);
        */

        // Получим строку из 2-х рандомных чисел
        // Результат сложения строки с числом – строка, не число
        String initial = String.valueOf(50) + 11;
        System.out.println(initial);

        /*
        // Соединяем строки через пробел
        // Первый аргумент метода – разделитель (передаем пробел)
        String result1 = String.join(" ", "Bombarda", "Maxima", "!");
        // Получим строку "Bombarda Maxima !"
        System.out.println(result1);

        String result2 = String.join(", ", "1", "2", "3", "4", "5");
        // Получим строку "1, 2, 3, 4, 5"
        System.out.println(result2);

        String res1 = String.format("Строка - %s, Число - %d", "Accio", 42);
        // Получим "Строка - Accio, Число - 42"
        System.out.println(res1);
         */

        // Создаём StringBuilder
        StringBuilder builder = new StringBuilder();

       // Друг за другом можно добавлять строки или числа в конец строки
        builder.append("Wingardium ")
                .append("Leviosa");

       // builder.toString() вернёт получившуюся строку
        String resultBuilder = builder.toString();
        // Wingardium Leviosa
        System.out.println(resultBuilder);

        StringBuilder sb = new StringBuilder("Wingardium Leviosa");
        // Границы строки и то, на что нужно заменить подстроку
        sb.replace(0, 9, "123456789");

        // Получим "123456789m Leviosa"
        System.out.println(sb);

        /*
        StringBuilder builder = new StringBuilder();
        builder.append("123")
        .append(456);

        // Метод перевернёт строку внутри StringBuilder
        builder.reverse();
        String result = builder.toString();

        // Получим строку "654321"
        System.out.println(result);
        */

        /*

        StringBuilder charm = new StringBuilder("Accio");
        // Указываем границы подстроки для удаления
        charm.delete(1, 3);
        // Получим "Aio" - начало включительно, конец - нет!
        System.out.println(charm);

        charm.deleteCharAt(0);
        charm.deleteCharAt(1);
        // Получим "i". Обратите внимание, результат предыдущих операций сохраняется
        System.out.println(charm);

        */
    }
}
