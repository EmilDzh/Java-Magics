package lesson4;
// циклы
public class Main {
    public static void main(String[] args) {
        // количество студентов в группе
        int studentsAmount = 20;

        for (int i = 1; i <= studentsAmount; i++) {
            System.out.println("Student №" + i + " says *Riddikulus*");
        }

        /*
        int studentsAmount = 20;
        int i = 1;
        while (i <= studentsAmount) {
        System.out.println("Student №" + i + " says *Riddikulus*");
        i++;
        }

        int studentsAmount = 20;

        for (int i = 1; i <= studentsAmount; i++) {
		if (someoneSeesDementor) {
				break;
		}
        System.out.println("Student №" + i + " says *Riddikulus*");
        }

        System.out.println("Oh, Harry");

        int studentsAmount = 20;

        for (int i = 1; i <= studentsAmount; i++) {
		if (someoneHasVertigo) {
				continue;
		}
        System.out.println("Student №" + i + " says *Riddikulus*");
        }


        */

    }
}
