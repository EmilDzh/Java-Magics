package lesson5.hw;

import java.util.Arrays;
import java.util.Scanner;

public class Potion {
    public static void main(String[] args) {

        Potion potion = new Potion();
        //potion.prepare();

        int [] nums = {1,-2,3,5,7};

        System.out.println(Arrays.toString(potion.findLowAndHighest(nums)));

    }// main

    public void prepare() {
        Scanner scanner = new Scanner(System.in);

        String[] ingredients = {"Драконий коготь", "Лист мандрагоры", "Корень шершавой астрелии."};

        System.out.println("Добро пожаловать в лабораторию зелий!” и " + " " + "Введите ингредиенты, которые у вас есть (через запятую)” ");

        String input = scanner.nextLine();

        String[] userIngredients = input.split(",");

        int temp = 0;

        for (int i = 0; i < ingredients.length; i++) {
            for (int j = 0; j < userIngredients.length; j++) {
                if (ingredients[i].equals(userIngredients[j])) {
                    temp++;
                }

            }
        }
        if (temp == userIngredients.length) {
            System.out.println("У вас есть все необходимые ингредиенты для зелья! Можете начинать создание.”");
        } else {
            System.out.println("У вас не хватает некоторых ингредиентов. Нельзя приступать к созданию зелья.”");
        }

        System.out.println(Arrays.toString(userIngredients));

    }

    public int[] findLowAndHighest(int[] numbers) {

        Arrays.sort(numbers);

        int[] res = new int[2];
        res[0] = numbers[0];
        res[1] = numbers[numbers.length - 1];

        System.out.println(Arrays.toString(numbers));

        return res;
    }
}
