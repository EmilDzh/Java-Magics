package lesson5;
// Массивы

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        String[] potion = new String[5];

        potion[0] = "Фиолетовая поганка";
        potion[1] = "Огромный кристалл";
        potion[2] = "Огненный цветок";
        potion[3] = "Голубой гриб";
        potion[4] = "Полынь";

        String[] potionSubset = Arrays.copyOfRange(potion, 1, 4);

        String[] superPotion = new String[111];
        // Получим 111
        System.out.println(superPotion.length);

        int[] score = {1, 2, 3, 4, 5};

        String[] potion1 = {"Фиолетовая поганка", "Огромный кристалл", "Огненный цветок"};
        String[] anotherPotion = potion.clone();

        // Получим true, потому что массивы равны
        System.out.println(Arrays.equals(potion1, anotherPotion));

        // Получим false, потому что мы склонировали массив уже в другом участке памяти
        System.out.println(potion.equals(anotherPotion));

        System.out.println(Arrays.toString(potion));

        //Как обычно, здесь подвох
        System.out.println(potion.toString());

        String[] boxWithFeathers = new String[100];
        Arrays.fill(boxWithFeathers, "Feather");

        Arrays.sort(potion);
        //Получим [Огненный цветок, Огромный кристалл, Фиолетовая поганка].

        //Arrays.sort(имяМассива, первыйЭлементВключительно, последнийЭлементНеВключительно);.

        /*

        int[] arr = {4, 8, 15, 16, 23, 42};
        // В массиве всего 6 элементов
        // Значит содержатся индексы только от 0 до 5, т.е. [0; n - 1]

        float incorrectIndex1 = 1.0;
        String incorrectIndex2 = "2";
        // Нельзя
        arr[-1];
        arr[6];
        arr[incorrectIndex1];
        arr[incorrectIndex2];

        int correctIndex1 = 3;
        long correctIndex2 = 4;
        // Можно
        arr[0];
        arr[5];
        arr[correctIndex1];
        arr[correctIndex2];

         */
    }
}
