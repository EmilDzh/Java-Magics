package lesson6;

public class HospitalQuestionnaire extends Questionnaire {
    private int age;
    private String complaints;
}
