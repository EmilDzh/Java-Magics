package lesson7;

import lesson7.beast.Hippogriff;

//Классы и Объекты
public class Main {
    public static void main(String[] args) {
        System.out.println("Oh, you’re a magician, friend! Welcome to Hogwarts!");

        Dragon blueDragon = new Dragon(); // можем создать прямо сейчас
        Dragon redDragon = new Dragon("Flame", 150, "red", true);  // не можем создать прямо сейчас

        System.out.println("Name: " + redDragon.getName());
        System.out.println("Age: " + redDragon.getAge());
        System.out.println("Color: " + redDragon.getColor());
        System.out.println("Can breathe fire: " + redDragon.isFireBreathing());

        redDragon.roar();

        Hippogriff hippogriff1 = new Hippogriff();
        hippogriff1.setName("set hippo name");
        Hippogriff hippogriff2 = new Hippogriff("hippo2", 3, "grey", true);
        Hippogriff hippogriff3 = new Hippogriff(1, "black");
        Hippogriff hippogriff4 = new Hippogriff("Only hippo");


    }
}
