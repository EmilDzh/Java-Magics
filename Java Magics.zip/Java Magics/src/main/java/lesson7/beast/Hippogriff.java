package lesson7.beast;

import lesson7.Student;

import java.util.Random;

public class Hippogriff {

    private String name;

    private int age;

    private String color;

    private boolean isAbleToFly;

    public Hippogriff(String name, int age, String color, boolean isAbleToFly) {
        this.name = name;
        this.age = age;
        this.color = color;
        this.isAbleToFly = isAbleToFly;
    }

    public Hippogriff(String name) {
        this.name = name;
    }

    public Hippogriff(int age, String color) {
        this.age = age;
        this.color = color;
    }

    public Hippogriff() {
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getColor() {
        return color;
    }

    public boolean isAbleToFly() {
        return isAbleToFly;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void eat(String food) {
        System.out.println("гиппогриф ни за что не будет есть какую-то еду: " + food + " " + " но другую, наоборот, с радостью");
    }

    public String fly() {
        if (this.age > 2) {
            return this.name + " он может летать!";
        } else {
            return this.name + "он еще слишком мал!";
        }
    }

    public String giveRide(Student student) {
        int isGivingRide = new Random().nextInt(1, 11); // Диапазон от 1 до 10 включительно

        if (isGivingRide <= 3) {
            return student.getName() + " летит на гиппогрифе!";
        } else if (isGivingRide <= 8) {
            return student.getName() + ": гиппогриф демонстративно отворачивается и отказывается катать!";
        } else {
            return student.getName() + ": студент должен попробовать снова.";
        }
    }
}
