package lesson3;

import java.util.Random;

// Ветвление
public class Main {
    public static void main(String[] args) {
        int branchCount = new Random().nextInt(0, 10); //у ветки есть вот столько маленьких веточек


        if (branchCount >= 8) {
            System.out.println("Кладем ветку в кучу больших веток");
        } else if (branchCount == 5) {
            System.out.println("Древороги (существо с деревянным рогом) едят только ветки с пятью веточками!");
        } else if (branchCount == 1) {
            System.out.println("Ну, это посох");
        } else {
            System.out.println("Такие нам сейчас не нужны. Будем топить ими камин");
        }

        int number = 4;

        if (number > 5) {
            number = number + 5;
            System.out.println("Теперь число больше 10");
        }
        System.out.println(number);
    }
}
