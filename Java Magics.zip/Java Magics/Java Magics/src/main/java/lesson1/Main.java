package lesson1;

public class Main {
    public static void main(String[] args) {

        // **[тип] [название]** *= [значение]*
        // float result;                    // объявление переменной
        // String name = "Ronald Weasley";  // объявление и инициализация переменной
        //int b, c = 4, d;                 // объявление нескольких переменных
        // byte e = 1;

        // int def_123 = 5;                 // правильное название переменной
        //int 123abc = 123;                // неправильное название переменной

        // float pi = 3.14f;
        // double e = 2.718281828;
        // int a = 3228;
        // long b = 12345678900987654321L;

        int a = 12, b = 4;
        int resultPlus = a + b;
        int resultMinus = a - b;
        int resultMul = a * b;
        int resultDiv = a / b;
        int result = resultPlus + resultMinus + resultMul + resultDiv - 1000;

        // по приотету сначала вычисляется умножение и деление,
        // а затем сумма и разность - все по математическим правилам
        // int a = 1 + 2 * 5;           // будет равно 11
        // int b = (1 + 2) * 5;         // будет равно 15
        // int c = 5 * 5 - (4 / 2 - 4); // будет равно 25 - (2 - 4) = 25 + 2 = 27

        /*

         int counter = 5;
         counter++;    // Постфиксный инкремент: сначала возвращает значение, затем добавляет единицу
         ++counter;    // Префиксный инкремент: сначала добавляет единицу, затем возвращает значение
         counter += 3; // Добавляет 3 к переменной
         counter /= 2; // Делит на 2
         counter *= 2; // Умножает на 2

         boolean isMuggle = false;
         boolean introCourseIsGreat = true;

         == — знак равенства, true если выражения по обе стороны равны

         != — знак неравенства, true если выражения по обе стороны не равны

         >, ≥, <, ≤ — операторы сравнения (работают только для чисел)

         && — означает И, т.е. выражения по обе стороны должны быть true

         || — означает ИЛИ, т.е. хотя бы одно выражение слева или справа должно быть true



         int number = new Random().nextInt();       // Создаем случайное число
         boolean isFirstEven = number % 2 == 0;     // true, если число чётное; иначе false
         boolean isFirstOdd = number % 2 != 0;      // true, если число нечётное; иначе false

         int number2 = new Random().nextInt();      // Создаем еще одно случайное число
         boolean isFirstBigger = number > number2;  // true, если первое число больше второго; иначе false
         boolean isFirstLowerOrEqual = number <= number2; // true, если первое число меньше или равно второму; иначе false

         // Можно использовать другие булевые переменные при вычислениях
         // Также можно расставлять скобки для задания приоритета операций
         boolean result = (isFirstEven && isFirstOdd) || isFirstBigger;

         char a = 'a'; // Код символа – 97 из таблицы ASCII
         char b = 'b'; // Код символа – 98 из таблицы ASCII

         char a = 'a';
         char b = 'b';

         int resultSum = a + b; // result = 97 + 98 = 195
         int resultDiv = a - b; // result = 97 - 98 = -1
        */
    }
}
