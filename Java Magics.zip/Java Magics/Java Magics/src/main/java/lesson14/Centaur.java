package lesson14;

public class Centaur {

    static String wisdom = "All centaurs have it";

    private final String veryImportantKnowledge;

    String name;

    public Centaur(String veryImportantKnowledge) {
        this.veryImportantKnowledge = veryImportantKnowledge;
    }

//    public static String getTheKnowledge() {
//        // Ошибка! Из static метода не можем обратится к обычной переменной
//        return veryImportantKnowledge + " I know more";
//    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static String getWisdom() {
        return wisdom;
    }

    public static void setWisdom(String wisdom) {
        Centaur.wisdom = wisdom;
    }

    public static void main(String[] args) {

        System.out.println(Centaur.wisdom);

        Centaur сentaur = new Centaur("bla bla");
        System.out.println(сentaur.wisdom);
    }


}
