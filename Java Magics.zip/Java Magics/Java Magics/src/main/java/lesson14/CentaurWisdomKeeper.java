package lesson14;

public class CentaurWisdomKeeper {

    public static String shareWisdom(Centaur centaur) {
        return "Centaur " + centaur.getName() + " now keep the wisdom";
    }

    public static void main(String[] args) {
        Centaur сentaur = new Centaur("asdasd");
        String result = CentaurWisdomKeeper.shareWisdom(сentaur);
        System.out.println(result);
    }
}
