package lesson17;

import java.util.List;

//List
public class ArrayList {
    public static void main(String[] args) {
        List<String> professors = new java.util.ArrayList<>();
        professors.add("Минерва Макгонаглл");
        professors.add("Снейп Северус");
        professors.add("Аластор Грюм");
        professors.add("Гораций Слизнорт");
        professors.add("Долорес Амбридж");
        professors.add("Златопуст Локонс");
        professors.add("Квиринус Квирелл");
        professors.add("Римус Люпин");
        professors.add("Рубеус Хагрид");
        professors.add("Альбус Дамблдор");

// массив автоматически увеличился!
        professors.add("Роланда Трюк");
        professors.add("Сивилла Трелони");

        List<String> youKnowWho = new java.util.ArrayList<>();
        youKnowWho.add("Lord");
        youKnowWho.add(" ");
        youKnowWho.add("Vol");
        youKnowWho.add("mort");

// Вставляем de на место третьего элемента
        youKnowWho.add(3, "de");

// В итоге выведется "Lord Voldemort"
        for (int i = 0; i < youKnowWho.size(); ++i) {
            System.out.print(youKnowWho.get(i));
        }

        // Получим "Минерва Макгонаглл"
        System.out.println(professors.get(0));
// Получим "Долорес Самбридж"
        System.out.println(professors.get(4));
// Получим "Квиринус Квирелл"
        System.out.println(professors.get(6));

// Получим ошибку ArrayIndexOutOfBoundsException:
// Index 7 out of bounds for length 7
        System.out.println(professors.get(7));

        professors.set(2, "Альбус Дамблдор");
/* Получим ["Минерва Макгонаглл", "Снейп Северус",
						"Альбус Дамблдор", "Гораций Слизнорт"] */
//        System.out.println(numbers);
//
//// Получим исключение IndexOutOfBoundsException
//        numbers.set(5, "Том Реддл");

        List<String> words = new java.util.ArrayList<>();
        words.add("Гарри");
        words.add(" ");
        words.add("любит");
        words.add(" ");
        words.add("метлу");

// Удаляем слово под индексом 2
        String result = words.remove(2);
// Получим "любит"
        System.out.println(result);

// В итоге получим "Гарри  метлу"
        for (int i = 0; i < words.size(); ++i) {
            System.out.print(words.get(i));
        }

        int index = words.indexOf("Аластор Грюм");
// Получим 2, т.к. первый встретившийся профессор "Аластор Грюм" находится под индексом 2
        System.out.println(index);

// Получим -1, т.к. "Том Реддл" в списке нет
        index = words.indexOf("Том Реддл");
        System.out.println(index);

        int lastIndexOf = words.lastIndexOf("Аластор Грюм");
// Получим 8
        System.out.println(lastIndexOf);

        lastIndexOf = words.lastIndexOf("Снейп Северус");
// Получим 6
        System.out.println(lastIndexOf);

        lastIndexOf = words.lastIndexOf("Златопуст Локонс");
// Получим 7
        System.out.println(lastIndexOf);

        List<String> result1 = professors.subList(2, 5);
// Получим ["Аластор Грюм", "Гораций Слизнорт", "Долорес Амбридж"]
        System.out.println(result);
    }
}
