package lesson17;


import java.util.ArrayList;
import java.util.List;

//LinkedList
public class LinkedList {
    public static void main(String[] args) {

        List<String> wizards = new ArrayList<>();
        wizards.add("Рон");
        wizards.add("Гарри");
        wizards.add("Гермиона");
        wizards.add("Хагрид");
        // Имеем такую структуру
        // null <- "Рон" <-> "Гарри" <-> "Гермиона" <-> "Хагрид" -> null
        // Каждый элемент ссылается на предыдущий и следующий
        // У боковых элементов есть ссылки на null

        // Было:
        // null <- "Рон" <-> "Гарри" <-> "Гермиона" <-> "Хагрид" -> null
        wizards.add(2, "Малфой");
        // Нам не нужно двигать всю правую часть массива
        // достаточно лишь для Гарри и Гермионы поправить ссылки
        // null <- "Рон" <-> "Гарри" <-> "Малфой" <-> "Гермиона" <-> "Хагрид" -> null

    }
}
