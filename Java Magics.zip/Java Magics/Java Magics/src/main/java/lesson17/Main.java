package lesson17;

import lesson17.hw.User;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        try {
            // Создаём список пользователей
            List<User> users = new ArrayList<>(
                    Arrays.asList(
                            new User("Alice", 25, "Google", "London"),
                            new User("Bob", 30, "Uber", "New York"),
                            new User("Charlie", 28, "Amazon", "Amsterdam"),
                            new User("Diana", 25, "Google", "London"),
                            new User("Eve", 29, "Uber", "New York")
                    )
            );

            // Группировка пользователей по возрасту
            Map<Integer, List<User>> groupedUsers = User.groupUsers(users);
            System.out.println("Группировка пользователей по возрасту:");
            groupedUsers.forEach((age, userList) -> {
                System.out.println("Возраст " + age + ": " + userList);
            });
        } catch (IllegalArgumentException e) {
            System.err.println("Ошибка: " + e.getMessage());
        }
    }
    
}
