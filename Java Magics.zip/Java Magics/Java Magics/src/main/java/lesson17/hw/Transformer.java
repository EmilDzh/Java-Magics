package lesson17.hw;

import java.util.ArrayList;
import java.util.List;

public class Transformer {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>(
                List.of("", "a", "b", "ab", "ba", "z", "h", "", "heh", "")
        );

        // нужно получить [aa, bb, ab, ba, zz, hh, heh]
        System.out.println(transform(list));
    }

    public static List<String> transform(List<String> words) {
        // Напишите свой код здесь

        List<String> res = new ArrayList<>();

        for (int i = 0; i < words.size() - 1; i++) {

            if (words.get(i).equals("")) {
                words.remove(i);
            }
            res.add(words.get(i));
        }

        return res;
    }
}
