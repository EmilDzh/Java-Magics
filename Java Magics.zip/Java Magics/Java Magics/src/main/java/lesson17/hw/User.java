package lesson17.hw;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class User {

    /*
    имя;

    возраст;

    место работы;

    адрес.
    */

    private String name;

    private int age;

    private String work;

    private String address;


    // Конструктор с валидацией
    public User(String name, int age, String work, String address) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Имя не может быть пустым.");
        }
        if (age < 18) {
            throw new IllegalArgumentException("Возраст должен быть не меньше 18.");
        }
        if (!VALID_JOBS.contains(work)) {
            throw new IllegalArgumentException("Место работы должно быть одним из: " + VALID_JOBS);
        }
        if (!VALID_ADDRESSES.contains(address)) {
            throw new IllegalArgumentException("Адрес должен быть одним из: " + VALID_ADDRESSES);
        }

        this.name = name;
        this.age = age;
        this.work = work;
        this.address = address;
    }

    private static final Set<String> VALID_JOBS = new HashSet<>(
            List.of("Google", "Uber", "Amazon")
    );

    private static final Set<String> VALID_ADDRESSES = new HashSet<>(
            List.of("London", "New York", "Amsterdam")
    );


    public static Map<Integer, List<User>> groupUsers(List<User> users) {

        Map<Integer, List<User>> res = new HashMap<>();

        for (User u : users) {

            Integer keyAge = u.age;

            if (!res.containsKey(keyAge)) {
                res.put(keyAge, new ArrayList<>());
            }

            res.get(keyAge).add(u);
        }

        return res;
    }

    // Переопределение toString для вывода пользователя
    @Override
    public String toString() {
        return String.format("User{name='%s', age=%d, work='%s', address='%s'}", name, age, work, address);
    }

}
