package lesson13;

import lesson13.hw.spells.ExpandingSpell;
import lesson13.hw.spells.ReducingSpell;
import lesson13.hw.spells.Spell;

//Абстрактные классы
public class Main {
    public static void main(String[] args) {

        Elf elf = new HouseElf();
        HouseElf houseElf = new HouseElf();
        SchoolElf schoolElf = new SchoolElf();

        elf.setName("Kreacher");
        elf.work();

        houseElf.setName("Dobby");
        houseElf.work();

        schoolElf.setName("Winky");
        schoolElf.setPaid(false);
        schoolElf.work();
        schoolElf.disappear();

        Spell spell = new ExpandingSpell("ExpandingSpell", "Expanding", true);

        spell.doMagic();

        ReducingSpell reducingSpell = new ReducingSpell("ReducingSpell", "Reducing", false);

        reducingSpell.doMagic();
    }
}
