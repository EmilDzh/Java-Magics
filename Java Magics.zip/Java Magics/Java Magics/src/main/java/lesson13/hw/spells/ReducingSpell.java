package lesson13.hw.spells;

public class ReducingSpell extends Spell{


    public ReducingSpell(String spellName, String spellEffeckt, boolean spellStatus) {
        super(spellName, spellEffeckt, spellStatus);
    }

    @Override
    public void doMagic() {
        castSpell();
    }

    public void castSpell(){
        System.out.println("было применено заклинание уменьшения. " + super.getSpellName());
    }
}
