package lesson13.hw.spells;

public abstract class Spell {

    private String spellName;

    private String spellEffeckt;

    private boolean spellStatus;

    public abstract void doMagic();

    public Spell(String spellName, String spellEffeckt, boolean spellStatus) {
        this.spellName = spellName;
        this.spellEffeckt = spellEffeckt;
        this.spellStatus = spellStatus;
    }

    public String getSpellName() {
        return spellName;
    }

    public void setSpellName(String spellName) {
        this.spellName = spellName;
    }

    public String getSpellEffeckt() {
        return spellEffeckt;
    }

    public void setSpellEffeckt(String spellEffeckt) {
        this.spellEffeckt = spellEffeckt;
    }

    public boolean isSpellStatus() {
        return spellStatus;
    }

    public void setSpellStatus(boolean spellStatus) {
        this.spellStatus = spellStatus;
    }
}
