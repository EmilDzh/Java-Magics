package lesson13.hw.spells;

public class ExpandingSpell extends Spell{


    public ExpandingSpell(String spellName, String spellEffeckt, boolean spellStatus) {
        super(spellName, spellEffeckt, spellStatus);
    }

    @Override
    public void doMagic() {
        castSpell();
    }

    public void castSpell(){
        System.out.println("было применено заклинание увеличения. " + super.getSpellName());
    }
}
