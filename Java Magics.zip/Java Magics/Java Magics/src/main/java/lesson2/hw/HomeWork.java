package lesson2.hw;

import java.util.Random;

public class HomeWork {
    public static void main(String[] args) {
        /*
        Первое задание
        Создайте строку из 5 случайных чисел new Random().nextInt().

        Замените все единицы на символ ‘i’.

        У получившейся строки уберите все символы ‘-’

        У получившейся строки замените все нули на символ ‘o’.

        У получившейся строки замените все шестерки на символ ‘b’.

        Выведите результат в консоль.

        Узнайте, содержится ли подстрока “23” у получившейся строки.

        Узнайте индекс подстроки “ob”.
          */

        Random random = new Random();
        // Генерация 5 случайных чисел в диапазоне от 0 до 9
        int randomInt1 = random.nextInt(10); // Число от 0 до 9
        int randomInt2 = random.nextInt(10);
        int randomInt3 = random.nextInt(10);
        int randomInt4 = random.nextInt(10);
        int randomInt5 = random.nextInt(10);

        // Формируем строку из чисел
        String randomString = "" + randomInt1 + randomInt2 + randomInt3 + randomInt4 + randomInt5;
        System.out.println("Исходная строка: " + randomString);

        // Выполняем замены
        randomString = randomString.replace("1", "i"); // Заменяем '1' на 'i'
        randomString = randomString.replace("-", "");  // Убираем '-'
        randomString = randomString.replace("0", "o"); // Заменяем '0' на 'o'
        randomString = randomString.replace("6", "b"); // Заменяем '6' на 'b'

        // Выводим обработанную строку
        System.out.println("Обработанная строка: " + randomString);

        // Проверяем наличие подстроки '23'
        boolean contains23 = randomString.contains("23");
        System.out.println("Содержит ли строка '23': " + contains23);

        // Находим индекс подстроки 'ob'
        int indexOfOb = randomString.indexOf("ob");
        System.out.println("Индекс подстроки 'ob': " + indexOfOb);


        castSpell();

    }

    public static void castSpell(){
        String str = "ARDENTIS VERUM LUMINOS ET FULGUR SYLVESTRA ELIXIA";
        str = str.toLowerCase();

        int start = new Random().nextInt(0, str.length());

        String randomStart = str.substring(start);

        StringBuilder spell = new StringBuilder();
        spell.append(randomStart);
        spell.reverse();

        char one = spell.charAt(0);
        char zero = spell.charAt(1);

        spell.replace(0,1, String.valueOf(zero));
        spell.replace(1,2, String.valueOf(one));

        System.out.println(spell);
    }
}
