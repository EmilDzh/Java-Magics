package lesson3.hw;

import java.util.Scanner;

public class SortingHat {
    public static void main(String[] args) {

        sort();

    }

    public static void sort(){

        String q1 = "Ты предпочитаешь работать в команде? (Да/Нет)";
        String q2 = "Ты любишь разгадывать головоломки? (Да/Нет)";
        String q3 = "Ты идешь на риск, чтобы достичь своей цели? (Да/Нет)";
        String q4 = "Ты проявляешь заботу к существам и природе? (Да/Нет)";

        Scanner scanner = new Scanner(System.in);

        System.out.println(q1);
        String a1 = scanner.nextLine();

        System.out.println(q2);
        String a2 = scanner.nextLine();

        System.out.println(q3);
        String a3 = scanner.nextLine();

        System.out.println(q4);
        String a4 = scanner.nextLine();

        // Логика распределения
        if (a1.equalsIgnoreCase("Да")) { // Если работает в команде
            if (a3.equalsIgnoreCase("Да")) { // И идет на риск
                System.out.println("Гриффиндор");
            } else if (a4.equalsIgnoreCase("Да")) { // И заботится о природе
                System.out.println("Пуффендуй");
            }
        } else if (a2.equalsIgnoreCase("Да")) { // Если любит головоломки
            if (a1.equalsIgnoreCase("Да")) { // И работает в команде
                System.out.println("Когтевран");
            } else if (a3.equalsIgnoreCase("Да")) { // И идет на риск
                System.out.println("Когтевран");
            } else {
                System.out.println("Слизерин");
            }
        } else if (a3.equalsIgnoreCase("Да")) { // Если идет на риск
            System.out.println("Слизерин");
        } else { // Если ничего из вышеперечисленного
            System.out.println("Пуффендуй");
        }


    }
}
