package lesson3.hw;

import java.util.Random;

public class HomeWork {
    public static void main(String[] args) {

        int r1 = new Random().nextInt();
        int r2 = new Random().nextInt();

        int sum = 0;

        if (r1 % 2 == 0 && r2 % 2 == 0) {
            int t1 = r1 / 2;
            int t2 = r2 / 2;

            sum = t1 + t2;
            System.out.println(sum);

        } else if (r1 % 2 == 0) {

            int t1 = r1 / 2;
            sum = t1 + r2;
            System.out.println(sum);

        } else if (r2 % 2 == 0) {

            int t2 = r2 / 2;

            System.out.println(t2);
        } else {
            System.out.println(r1 + r2);
        }

        System.out.println(sum);
    }
}
