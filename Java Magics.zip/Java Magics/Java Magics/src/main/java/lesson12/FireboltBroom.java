package lesson12;

public class FireboltBroom implements Flyable{

    private int startSpeed = 0;

    private int maxSpeed = 4000;

    private int minSpeed = 10;


    @Override
    public void fly() {
        System.out.println("Broom takes off with speed " + startSpeed);
    }

    @Override
    public void accelerate() {
        System.out.println("Broom may accelerate up to " + maxSpeed);
    }

    @Override
    public void slowDown() {
        System.out.println("If the speed is at " +  minSpeed + ", the broom will stop");
    }

    public void autopilot() {
        System.out.println("Broom flies by itself. You can catch snitch!");
    }
}
