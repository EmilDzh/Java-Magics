package lesson12;

import lesson12.hw.items.Car;
import lesson12.hw.items.Cloak;
import lesson7.Student;

// Interfaces
public class Main {
    public static void main(String[] args) {

        FireboltBroom fireboltBroom = new FireboltBroom();
        NimbusBroom nimbusBroom = new NimbusBroom();

        /*
        Flyable broom = new FireboltBroom();

        Мы не можем создать объект самого интерфейса, то есть написать new Flyable,
        потому что интерфейс не хранит никакого состояния. Это будет ошибкой.
        Но зато мы можем интерфейсу присвоить его конкретную реализацию, например, FireboltBroom.
        В этом случае у объекта broom будут только те методы, которые описаны в интерфейсе,
        но не будет того уникального метода, который присущ только классу FireboltBroom.

        */

        Car car = new Car();
        Student student = new Student("Ron", "Griffi", 9, new String[]{"bla ", "bla"});

        car.setDriver(student);
        car.setSpeed(3);
        car.setFlying(true);

        if (car.isFlying())
            car.becomeInvisible();
        else
            car.becomeVisible();

        Cloak cloak = new Cloak();
        cloak.setCapacity(2);
        cloak.setWeight(1);

        if (cloak.getCapacity() == 4)
            cloak.becomeVisible();
        else
            cloak.becomeInvisible();
    }

}
