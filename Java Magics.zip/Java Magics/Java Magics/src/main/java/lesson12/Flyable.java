package lesson12;

public interface Flyable {
    public void fly();

    public void accelerate();

    public void slowDown();
}
