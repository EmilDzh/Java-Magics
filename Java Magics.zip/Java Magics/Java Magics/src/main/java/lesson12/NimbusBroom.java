package lesson12;

public class NimbusBroom implements Flyable {

    private int startSpeed = 10;

    private int maxSpeed = 1500;

    private int minSpeed = 0;

    @Override
    public void fly() {
        System.out.println("Broom takes off with speed " + startSpeed);
    }

    @Override
    public void accelerate() {
        System.out.println("Broom may accelerate up to " + maxSpeed);
    }

    @Override
    public void slowDown() {
        System.out.println("If the speed is at " + minSpeed + ", the broom will stop");
    }

    public void hover() {
        System.out.println("Broom hung in the air");
    }
}
