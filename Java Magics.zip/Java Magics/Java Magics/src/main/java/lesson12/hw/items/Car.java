package lesson12.hw.items;

import lesson7.Student;

public class Car implements Invisible{

    Student driver;

    int speed;

    boolean isFlying;

    public Student getDriver() {
        return driver;
    }

    public void setDriver(Student driver) {
        this.driver = driver;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public boolean isFlying() {
        return isFlying;
    }

    public void setFlying(boolean flying) {
        isFlying = flying;
    }

    @Override
    public void becomeInvisible() {
        System.out.println("машина сейчас невидима.");
    }

    @Override
    public void becomeVisible() {
        System.out.println("машина видима!");
    }
}
