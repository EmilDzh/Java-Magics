package lesson12.hw.items;

public interface Invisible {

    public void becomeInvisible();

    public void becomeVisible();
}
