package lesson12.hw.items;

public class Cloak implements Invisible{

    int capacity;

    int weight;

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    @Override
    public void becomeInvisible() {
        System.out.println("люди, которые сейчас под плащом — не видны");
    }

    @Override
    public void becomeVisible() {
        System.out.println("люди сейчас видны!");
    }
}
