package lesson15;

/*
  Сортировка коллекций
   Сортировка коллекций является важной операцией во многих приложениях.
   В Java для сортировки коллекций используются интерфейсы Comparable и Comparator.

   Comparable определяет метод int compareTo(T o), который позволяет сравнивать объекты и
   устанавливать их порядок сортировки. Классы, реализующие интерфейс Comparable, могут быть
   сравнимыми и использоваться для сортировки коллекций. Контракт такой:

   Если вернулось отрицательное число, значит текущий (this) объект меньше переданного;

   Если вернулся 0, значит объекты равны;

   Если вернулось положительное число, значит текущий (this) элемент больше переданного.
 */

public class Wisard implements Comparable<Wisard>{

    private String name;

    private int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public int compareTo(Wisard other) {
        return this.age - other.age;
    }
}
