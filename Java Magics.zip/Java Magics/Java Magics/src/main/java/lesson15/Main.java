package lesson15;

import lesson7.Student;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

//Collections
//Collections — это набор классов и интерфейсов, предназначенных для хранения и управления группами объектов в Java.
// Это структуры данных, которые позволяют эффективно организовывать,
// добавлять, удалять и обрабатывать данные в структурированном формате.
public class Main {
    public static void main(String[] args) {

        List<Student> students = new ArrayList<>();
        students.add(new Student("Harry Potter", "Griffindor", 13, new String[]{"to wear glasses"}));
        students.add(new Student("Hermione Granger", "Griffindor", 10, new String[]{"to be smart"}));
        students.add(new Student("Ron Weasley", "Griffindor", 13, new String[]{"to be lazy"}));
        students.add(new Student("Draco Malfoy", "Slytherin", 12, new String[]{"to be ambitious"}));
        students.add(new Student("Luna Lovegood", "Ravenclaw", 14, new String[]{"to be creative"}));


        // Сортировка по возрасту (Comparable)
        System.out.println("Сортировка по возрасту:");
        Collections.sort(students);
        students.forEach(System.out::println);

        // Сортировка по имени (Comparator)
        System.out.println("\nСортировка по имени (по алфавиту):");
        students.sort(Student.nameComparator);
        students.forEach(System.out::println);

        // Сортировка по факультету (Comparator, в убывающем порядке)
        System.out.println("\nСортировка по факультету (в обратном алфавитном порядке):");
        students.sort(Student.facultyComparator);
        students.forEach(System.out::println);
    }
}
