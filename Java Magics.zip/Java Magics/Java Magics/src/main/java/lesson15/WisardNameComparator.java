package lesson15;

import java.util.Comparator;

public class WisardNameComparator implements Comparator<Wisard> {
    // Реализовано сравнение по именам волшебников в алфавитном порядке
    @Override
    public int compare(Wisard wisard1, Wisard wisard2) {
        return wisard1.getName().compareTo(wisard2.getName());
    }
}
