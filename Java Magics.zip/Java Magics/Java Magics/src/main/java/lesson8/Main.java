package lesson8;

//Примитивные и ссылочные типы данных
public class Main {
    public static void main(String[] args) {
        Integer a = 5;
        String str = "Hello!";
        Long l = 20L;
        Character ch = 'a';

        Integer b = new Integer(6);

        String s1 = "Dragon";
        String s2 = "Dragon";
        String s3 = new String("Dragon");

        System.out.println("s1 == s2 :"+(s1==s2));
        System.out.println("s1 == s3 :"+(s1==s3));

//        Integer i1 = 10;
//        Integer i2 = 10;
//        Integer i3 = new Integer(10);
//        System.out.println("i1 == i2 : " + i1 == i2);
//        System.out.println("i2 == i3 : " + i2 == i3);
//
//        Integer i1 = 130;
//        Integer i2 = 130;
//        System.out.println(i1 == i2);

        int num = 42; // Примитивный тип int
        Integer numObj = num; // Автоупаковка: значение 42 упаковывается в объект Integer

        /*Integer numObj = 42; // Объект Integer
        int num = numObj; // Автораспаковка: значение из объекта Integer извлекается и присваивается переменной num
        */

    }
}
