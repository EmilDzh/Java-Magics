package lesson4.hw;

import java.util.Random;

public class Quidditch {
    public static void main(String[] args) {

        Quidditch quidditch = new Quidditch();
        quidditch.getBalls();
        quidditch.playGame();

        int sumOfOdds = 0;

        for (int i = 222; i < 444; i++) {

            if (i % 2 == 0){
                sumOfOdds = sumOfOdds + i;
            }
        }
        System.out.println(sumOfOdds);
    }

    public void getBalls() {

        for (int i = 1; i <= 3; i++) {
            System.out.print("Запущен мяч под названием: " + i);

            if (i == 1) {
                System.out.println(" Quaffle");
            }
            if (i == 2) {
                System.out.println(" Bludger");
            }
            if (i == 3) {
                System.out.println(" Golden Snitch");
            }
        }
    }

    public void playGame() {

        while (true) {

            int control = new Random().nextInt(0, 100);

            int someInt = 77;
            if (control == someInt) {
                System.out.println("Снитч пойман");
                break;
            } else {
                System.out.println("!");
            }
        }
    }
}
