package lesson10;

public class EnchantedSpell {

    private String spellName;
    private int spellLevel;
    private boolean isHidden;

    public EnchantedSpell(String spellName, int spellLevel, boolean isHidden) {
        this.spellName = spellName;
        this.spellLevel = spellLevel;
        this.isHidden = isHidden;
    }

    public void castSpell() {
        if (isHidden) {
            System.out.println("You've uncovered the hidden spell!");
        } else {
            System.out.println("Casting " + spellName + " at level " + spellLevel + "!");
        }
    }

    public void revealSpell() {
        isHidden = false;
        System.out.println("You've successfully revealed the hidden spell: " + spellName);
    }

    public String getSpellName() {
        return spellName;
    }

    public void setSpellName(String spellName) {
        this.spellName = spellName;
    }

    public int getSpellLevel() {
        return spellLevel;
    }

    public void setSpellLevel(int spellLevel) {
        this.spellLevel = spellLevel;
    }

    public boolean isHidden() {
        return isHidden;
    }

    public void setHidden(boolean hidden) {
        isHidden = hidden;
    }
}
