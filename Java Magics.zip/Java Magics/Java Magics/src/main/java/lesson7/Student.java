package lesson7;

import lesson11.hw.Spell;
import lesson11.hw.SpellCastException;
import lesson15.Wisard;

import java.util.Comparator;

public class Student implements Comparable<Student>{

    private String name;

    private String faculty;

    private int age;

    private String[] skills = new String[3];

    public Student(String name, String faculty, int age, String[] skills) {
        this.name = name;
        this.faculty = faculty;
        this.age = age;
        this.skills = skills;
    }

    public String getName() {
        return name;
    }

    public String getFaculty() {
        return faculty;
    }

    public int getAge() {
        return age;
    }

    public String[] getSkills() {
        return skills;
    }

    public void castSpell(Spell spell){
        if(this.age <= 11){
            if (spell.getPower() == 1){
                System.out.println(this.name + " использовал заклинание " + spell.getTitle());
            } else {
                throw new SpellCastException(this.name + " еще слишком юн, чтобы использовать " + spell.getTitle());
            }
        } else if (this.age <= 12) {
            if (spell.getPower() == 2){
                System.out.println(this.name + " использовал заклинание " + spell.getTitle());
            } else {
                throw new SpellCastException(this.name + " еще слишком юн, чтобы использовать " + spell.getTitle());
            }
        } else if (this.age >= 17) {
            System.out.println(this.name + " Этому студенту разрещено все");
        }
    }


    // Компаратор для сортировки по имени (по алфавиту)
    public static Comparator<Student> nameComparator = Comparator.comparing(Student::getName);

    // Компаратор для сортировки по факультету (в убывающем алфавитном порядке)
    public static Comparator<Student> facultyComparator = (s1, s2) -> s2.getFaculty().compareTo(s1.getFaculty());

    // Переопределение toString для красивого вывода
    @Override
    public String toString() {
        return String.format("Student{name='%s', faculty='%s', age=%d}", name, faculty, age);
    }

    // Реализация Comparable (сортировка по возрасту)
    @Override
    public int compareTo(Student other) {
        return Integer.compare(this.age, other.age);
    }
}
