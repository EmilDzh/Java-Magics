package lesson7;

public class Dragon {
    String name;
    int age;
    String color;
    boolean isFireBreathing;

    public String getName() {
        return name;
    }

    public void roar() {
        System.out.println("Roooaaarrr!");
    }

    public Dragon() {
    }

    public Dragon(String name, int age, String color, boolean isFireBreathing) {
        this.name = name;
        this.age = age;
        this.color = color;
        this.isFireBreathing = isFireBreathing;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public boolean isFireBreathing() {
        return isFireBreathing;
    }

    public void setFireBreathing(boolean fireBreathing) {
        isFireBreathing = fireBreathing;
    }
}
