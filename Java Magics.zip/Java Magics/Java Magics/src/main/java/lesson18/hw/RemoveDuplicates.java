package lesson18.hw;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RemoveDuplicates {
    public static void main(String[] args) {
        List<Integer> numbers = List.of(1, 2, 3, 2, 4, 5, 3, 6, 7, 5);
        // Напишите свой код здесь

        Set<Integer> sortNumbers = new HashSet<>(numbers);
        System.out.println(numbers);
        System.out.println(sortNumbers);
    }
}
