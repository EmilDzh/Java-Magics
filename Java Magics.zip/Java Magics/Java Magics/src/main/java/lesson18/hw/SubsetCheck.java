package lesson18.hw;

import java.util.HashSet;

public class SubsetCheck {
    public static void main(String[] args) {
        HashSet<Integer> set1 = new HashSet<>();
        HashSet<Integer> set2 = new HashSet<>();

        set1.add(1);
        set1.add(2);
        set1.add(3);
        set1.add(4);

        set2.add(2);
        set2.add(3);

        // Напишите свой код здесь

        boolean isSubset = set1.containsAll(set2);

        if (isSubset) {
            System.out.println("setB является подмножеством set1.");
        } else {
            System.out.println("setB не является подмножеством set1.");
        }
    }
}
