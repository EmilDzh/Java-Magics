package lesson18;

import java.util.HashSet;
import java.util.Set;

//Set
public class Main {
    public static void main(String[] args) {
        Set<String> characters = new HashSet();

        characters.add("Малфой");
        characters.add("Крэбб");
        characters.add("Гойл");
    }
}
