package lesson11;

import lesson11.hw.Spell;
import lesson11.hw.SpellCastException;
import lesson7.Student;

// Исключения
/*

 */
public class Main {
    public static void main(String[] args) {
        try {
            // пытаемся сделать что-то
        } catch (Exception e) {
            // описываем, что делать, если не получилось
        }

        try {
            throw new SpellNotFoundException("Такого заклинания в книге нет");
        } catch (SpellNotFoundException e) {
            System.out.println("Поймали свое исключение: " + e.getMessage());
        }

        Student student = new Student("Гарри Поттер", "Griffindor" ,11, new String[]{"bla", "halo"});
        Spell spell = new Spell("Левиоса", 2);

        try {
            // Пытаемся вызвать метод castSpell
            student.castSpell(spell);
        } catch (SpellCastException e) {
            // Обрабатываем исключение
            System.out.println("Ошибка: " + e.getMessage());
        }

    }

    public void doMagic() throws Exception {
        // пытаемся сделать что-то
        // если не получится, исключение надо будет обработать в каком-то другом месте
    }

    /*
       public static void castSpell() throws IOException {
       if(youDontKnowSpell) {
	   learnSpell();
      }
    }

       public static void learnSpell() throws IOException {
       goToLibrary();
    }

       public static void goToLibrary() throws IOException {
       if(bookNotFound) {
	   throw new IOException("Книга не найдена!");
    }
 }

      public static void main(String[] args) {
      castSpell();
  }

    public static void castSpell() {
     if(youDontKnowSpell) {
	 learnSpell();
    }
  }

   Множественный catch

   public static void learnSpell() {
     try {
	 goToLibrary();
     } catch(IOException e) {
	 System.out.println("Придется поискать другую книгу");
	 goToLibrary();
     } finally {
        System.out.println("Мы попытались");
     }
   }

   public static void goToLibrary() throws IOException {
      if(bookNotFound) {
	  throw new IOException("Книга не найдена!");
      }
  }

      public static void learnSpell() {
    try {
	goToLibrary();
    } catch(BookNotFoundException e) {
	System.out.println("Придется поискать другую книгу");
	goToLibrary();
    } catch(NotSkilledEnoughException e) {
	System.out.println("Не хватает знаний, чтобы изучить заклинание");
    } finally {
        System.out.println("Мы попытались");
    }
   }

     public static void goToLibrary() throws IOException {
    if(bookNotFound) {
	throw new BookNotFoundException("Книга не найдена!");
    }
    if(notSkilledEnough) {

*/


}
