package lesson11.hw;

public class SpellCastException extends RuntimeException{

    public SpellCastException(String message) {
        super(message);
    }
}
