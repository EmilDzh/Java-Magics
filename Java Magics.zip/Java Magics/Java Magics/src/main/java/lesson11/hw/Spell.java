package lesson11.hw;

public class Spell {

    private String title;
    private int power = 4;

    public Spell(String title, int power) {
        this.title = title;
        this.power = power;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }
}
