package lesson11;

public class SpellNotFoundException extends Exception{

    public SpellNotFoundException(String message) {
        super(message);
    }
}
