package lesson16.hw;

/*
  Вам дан массив, напишите алгоритм, который посчитает количества уникальных чисел используя HashMap.
  В итоге должен получиться словарь [1->3, 2->2, 3->2, 4->2, 5]
 */

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class CountOccurrences {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 2, 1, 3, 4, 5, 1};
        // Напишите свой код здесь

        System.out.println(findUniques(arr));

    }

    public static Map<Integer, Integer> findUniques(int[] numbers) {

        Map<Integer, Integer> res = new HashMap<>();

        for (int i = 0; i < numbers.length; i++) {

            Integer quantity = res.get(numbers[i]);

            if (quantity == null) {
                res.put(numbers[i], 1);
            } else {
                res.put(numbers[i], quantity + 1);
            }
        }
        return res;


    }
}
