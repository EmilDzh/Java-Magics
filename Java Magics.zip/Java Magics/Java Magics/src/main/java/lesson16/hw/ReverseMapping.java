package lesson16.hw;

import java.util.HashMap;
import java.util.Map;

public class ReverseMapping {
    public static void main(String[] args) {
        HashMap<String, String> capitalCountryMap = new HashMap<>();
        capitalCountryMap.put("Paris", "France");
        capitalCountryMap.put("Berlin", "Germany");
        capitalCountryMap.put("Rome", "Italy");

        HashMap<String, String> countryCapitalMap = new HashMap<>();
        // Напишите свой код здесь

        for (Map.Entry<String, String> entry : capitalCountryMap.entrySet()){
            countryCapitalMap.put(entry.getValue(), entry.getKey());
        }

        System.out.println(countryCapitalMap);
    }
}
