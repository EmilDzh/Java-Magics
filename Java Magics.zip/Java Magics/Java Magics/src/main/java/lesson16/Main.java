package lesson16;

import lesson16.hw.Student;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//Map
public class Main {
    public static void main(String[] args) {
        // Создадим HashMap. Ключом будет имя человека,
        // а значением - его возраст.
        Map<String, Integer> map = new HashMap<>();

        // Добавим элементы (пары ключ-значение).
        // Для этого используем метод put()
        map.put("Alice", 28);
        map.put("Dima", 25);
        map.put("Vasya", 18);

        // Получим значение по ключу
        Integer ageOfAlice = map.get("Alice");
        System.out.println("Возраст Alice: " + ageOfAlice);

        // Чтобы удалить элемент по ключу, используем метод remove()
        map.remove("Alice");

        // Проверка наличия ключа
        System.out.println("Содержит ли HashMap ключ 'Alice': " +
                map.containsKey("Alice"));

        // Итерация по элементам HashMap
        System.out.println("Итерация по элементам HashMap:");
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(
                    "Имя: " + entry.getKey() + ", Возраст: " + entry.getValue()
            );
        }

        List<Student> students = new ArrayList<>(
                Arrays.asList(
                        new Student("Anton Shkredov", "Backend Dev", 1),
                        new Student("Sofa Abashidze", "Front-End Dev", 3),
                        new Student("Reiner Braun", "FullStack Dec", 2),
                        new Student("Konstantin Bahutski", "Backend Dev", 4),
                        new Student("Annie Leonhart", "QA tester", 3),
                        new Student("Falco Eldian", "FullStack Dev", 2)

                ));

        // Вызов метода aboutStudents
        Map<String, List<Student>> groupedStudents = aboutStudents(students);

        // Вывод результата
        groupedStudents.forEach((key, value) -> {
            System.out.println(key + ": " + value);
        });

        // Добавление нового студента
        addStudent(students, new Student("Eren Yeager", "Backend Dev", 1));

        // Удаление студента
        removeStudent(students, "Anton Shkredov", "Backend Dev", 1);

        // Поиск студентов факультета и курса
        List<Student> foundStudents = findStudents(students, "FullStack Dev", 2);
        System.out.println("Студенты FullStack Dev, курс 2:");
        foundStudents.forEach(System.out::println);


    }

    // Создайте метод, который будет принимать список студентов и возвращать HashMap с ключом,
    // состоящим из пары faculty и year,
    // и значением — списком студентов, соответствующих данному факультету и курсу.

    public static Map<String, List<Student>> aboutStudents(List<Student> students) {

        Map<String, List<Student>> result = new HashMap<>();


        for (Student s : students) {

            String key = s.getFaculty() + "-" + s.getYear();

            if (!result.containsKey(key)) {
                result.put(key, new ArrayList<>());
            }

            result.get(key).add(s);

        }

        return result;
    }

    // Метод для добавления нового студента
    public static void addStudent(List<Student> students, Student student) {
        students.add(student);
    }

    // Метод для удаления студента
    public static void removeStudent(List<Student> students, String name, String faculty, int year) {
        students.removeIf(s -> s.getName().equals(name) && s.getFaculty().equals(faculty) && s.getYear() == year);
    }

    // Метод для поиска студентов по факультету и курсу
    public static List<Student> findStudents(List<Student> students, String faculty, int year) {
        List<Student> result = new ArrayList<>();
        for (Student student : students) {
            if (student.getFaculty().equals(faculty) && student.getYear() == year) {
                result.add(student);
            }
        }
        return result;
    }
}
