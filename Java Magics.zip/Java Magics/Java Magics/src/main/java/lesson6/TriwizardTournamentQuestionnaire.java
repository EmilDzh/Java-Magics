package lesson6;

public class TriwizardTournamentQuestionnaire extends Questionnaire{
    int age;
    boolean uniqueSpells;
    boolean broomSkilled;

    public void getInfo() {
        System.out.println("Имя: " + super.getName() + ", Возраст: " + age);
    }
}
