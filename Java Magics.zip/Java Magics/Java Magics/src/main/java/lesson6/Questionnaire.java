package lesson6;

public class Questionnaire {
    private String name;
//    private int age;
//    private boolean uniqueSpells;
//    private boolean broomSkilled;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void getInfo() {
        System.out.println("Имя: " + name);
    }
}
